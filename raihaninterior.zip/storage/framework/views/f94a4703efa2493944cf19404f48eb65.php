<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<?php $__env->startSection('content'); ?>
<style>
@media (max-width: 768px) {
    .page-header {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .breadcrumbs {
        padding-left: 0 !important;
        margin-left: 0 !important;
    }
}
</style>
<div class="wrapper">
    <div class="main-header">
        <?php echo $__env->make('layouts.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <div class="page-header">
                    <h4 class="page-title"><?php echo e($judul); ?></h4>
                    <ul class="breadcrumbs">
                        <a href="<?php echo e(route('comment.add')); ?>" class="btn btn-round text-white ml-auto fw-bold" style="background-color: #B78D65">
                            <i class="fa fa-plus-circle mr-1"></i>
                            New Comments
                        </a>
                    </ul>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $DataC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card card-annoucement card-round" style="background-color: #B78D65">
                            <div class="card-body text-center">
                                <div class="card-opening text-white"><?php echo e($C->author_comments); ?></div>
                                <div class="card-desc text-white">
                                    <?php echo Str::limit(strip_tags($C->content_comments, '<b><i><u><strong><em>'), 135, '...'); ?>

                                </div>
                                <div class="card-detail">
                                    <a href="<?php echo e(route('comment.edit', $C->id_comments)); ?>">
                                        <button type="button" class="btn btn-icon btn-round btn-warning">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                    </a>
                                    <a href="<?php echo e(route('comment.delete', $C->id_comments)); ?>" class="but-delete">
                                        <button type="button" class="btn btn-icon btn-round btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </a>
                                    <?php if(Auth::user()->level == 'Super Admin'): ?>
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-icon btn-round btn-success" data-toggle="modal" data-target="#<?php echo e($C->id_comments); ?>">
                                            <i class="fas fa-history"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="<?php echo e($C->id_comments); ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo e($C->id_comments); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="<?php echo e($C->id_comments); ?>Label"><b>Activity History</b></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body" style="text-align: start">
                                                        <p>Created : <br><?php echo e($C->created_by); ?> <b>(<?php echo e($C->created_at); ?>)</b></p>
                                                        <p>Last Modified : <br><?php echo e($C->modified_by); ?> <b>(<?php echo e($C->updated_at); ?>)</b></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php echo $__env->make('layouts.admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).on('click','.but-delete',function(e) {

        e.preventDefault();
        const href1 = $(this).attr('href');

        Swal.fire({
            title: 'Are you sure?',
            text: "This data will be Permanently Deleted!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#fd7e14',
            confirmButtonText: 'DELETE',
            cancelButtonText: 'CANCEL'
            }).then((result) => {
            if (result.isConfirmed) {
                document.location.href = href1;
            }
        });
    });

    //message with sweetalert
    <?php if(session('success')): ?>
    Swal.fire({
        icon: "success",
        title: "<?php echo e(session('success')); ?>",
        showConfirmButton: false,
        timer: 3000
    });
    <?php elseif(session('error')): ?>
    Swal.fire({
        icon: "error",
        title: "<?php echo e(session('error')); ?>",
        showConfirmButton: false,
        timer: 3000
    });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH D:\Laragon\www\raihaninterior\resources\views/pages/admin/comment.blade.php ENDPATH**/ ?>