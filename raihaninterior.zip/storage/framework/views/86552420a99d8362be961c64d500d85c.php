<!--Div where the WhatsApp will be rendered-->
<div id="myDiv"></div>
<script type="text/javascript">
$(function () {
    $('#myDiv').floatingWhatsApp({
    phone: '6282228220233',
    size: '70px',
    // popupMessage: 'Hai, Ada yang bisa saya bantu?',
    // showPopup: false,
    position: "right"
    });
});
</script>

<!-- Footer Start -->
<div class="container-fluid bg-dark text-body footer mt-0 pt-0 px-0 wow fadeIn" data-wow-delay="0.1s">
    
    <div class="container-fluid copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-0 mb-md-0">
                    <p class="mb-0">Copyright &copy; <?= date("Y")?> : <a href="#"><b>Raihan Interior</b></a> - All Rights Reserved</p>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
<?php /**PATH D:\Laragon\www\raihaninterior\resources\views/layouts/public/footer.blade.php ENDPATH**/ ?>