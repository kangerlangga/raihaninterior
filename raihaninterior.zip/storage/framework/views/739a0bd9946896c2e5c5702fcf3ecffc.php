<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<?php $__env->startSection('content'); ?>
<style>
@media (max-width: 768px) {
    .page-header {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .breadcrumbs {
        padding-left: 0 !important;
        margin-left: 0 !important;
    }
}
</style>
<div class="wrapper">
    <div class="main-header">
        <?php echo $__env->make('layouts.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <div class="page-header">
                    <h4 class="page-title"><?php echo e($judul); ?></h4>
                    <ul class="breadcrumbs">
                        <a href="<?php echo e(route('user.add')); ?>" class="btn btn-round text-white ml-auto fw-bold" style="background-color: #B78D65">
                            <i class="fa fa-plus-circle mr-1"></i>
                            New Users
                        </a>
                    </ul>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $DataU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $U): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card card-profile">
                            <div class="card-header" style="background-color: #B78D65">
                                <div class="profile-picture">
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(url('')); ?>/assets/admin/img/user.png" alt="..." class="avatar-img rounded-circle" style="background-color: white">
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="user-profile text-center">
                                    <div class="name"><?php echo e($U->name); ?></div>
                                    <div class="job"><?php echo e($U->jabatan); ?></div>
                                    <div class="desc"><?php echo e($U->email); ?></div>
                                    <div class="view-profile">
                                        <a href="<?php echo e(route('user.edit', $U->id_akun)); ?>">
                                            <button type="button" class="btn btn-icon btn-round btn-warning">
                                                <i class="fas fa-pen"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('user.delete', $U->id_akun)); ?>" class="but-delete">
                                            <button type="button" class="btn btn-icon btn-round btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('user.resetpass', $U->id_akun)); ?>" class="but-resetpass">
                                            <button type="button" class="btn btn-icon btn-round btn-primary">
                                                <i class="fas fa-undo-alt"></i>
                                            </button>
                                        </a>
                                        <?php if(Auth::user()->level == 'Super Admin'): ?>
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-icon btn-round btn-success" data-toggle="modal" data-target="#<?php echo e($U->id_akun); ?>">
                                                <i class="fas fa-history"></i>
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="<?php echo e($U->id_akun); ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo e($U->id_akun); ?>Label" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="<?php echo e($U->id_akun); ?>Label"><b>Activity History</b></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body" style="text-align: start">
                                                            <p>Created : <br><?php echo e($U->created_by); ?> <b>(<?php echo e($U->created_at); ?>)</b></p>
                                                            <p>Last Modified : <br><?php echo e($U->modified_by); ?> <b>(<?php echo e($U->updated_at); ?>)</b></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php echo $__env->make('layouts.admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).on('click','.but-delete',function(e) {

        e.preventDefault();
        const href1 = $(this).attr('href');

        Swal.fire({
            title: 'Are you sure?',
            text: "This data will be Permanently Deleted!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#fd7e14',
            confirmButtonText: 'DELETE',
            cancelButtonText: 'CANCEL'
            }).then((result) => {
            if (result.isConfirmed) {
                document.location.href = href1;
            }
        });
    });

    $(document).on('click','.but-resetpass',function(e) {

        e.preventDefault();
        const href1 = $(this).attr('href');

        Swal.fire({
            title: 'The Password for This Account Will Be Reset!',
            text: "Default = #Raihan.Interior4021910",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#fd7e14',
            confirmButtonText: 'RESET PASSWORD',
            cancelButtonText: 'BATAL'
            }).then((result) => {
            if (result.isConfirmed) {
                document.location.href = href1;
            }
        });
    });

    //message with sweetalert
    <?php if(session('success')): ?>
    Swal.fire({
        icon: "success",
        title: "<?php echo e(session('success')); ?>",
        showConfirmButton: false,
        timer: 3000
    });
    <?php elseif(session('error')): ?>
    Swal.fire({
        icon: "error",
        title: "<?php echo e(session('error')); ?>",
        showConfirmButton: false,
        timer: 3000
    });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH D:\Laragon\www\raihaninterior\resources\views/pages/admin/user.blade.php ENDPATH**/ ?>